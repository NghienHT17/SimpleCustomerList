package com.example.customermanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
